#ifndef CAMERA_H_INCLUDED
#define CAMERA_H_INCLUDED

struct SCamera {
    float x,y,z;
    float XTor,ZTor;
};

void CameraApply();
void CameraTorsion(float xTilt, float zTilt);
void CamerAutoMouse(int centerX, int centerY, float speed);
void CameraDirectional(int forwardMove, int rightMove, float speed);

#endif // CAMERA_H_INCLUDED
